$.ajax({
    url:"xxxx",
    type:"post",
    data:{
        "xxx":"xxx"
    },
    dataType:"json",
    success:function (response) {

    },
    error:function () {

    }
})