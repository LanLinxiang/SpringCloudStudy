package com.llx.crm.settings.service;

import com.llx.crm.settings.dao.DictionaryTypeDao;
import com.llx.crm.settings.domain.DicType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Title: DictionaryTypeServiseImpl
 * Description:
 *
 * @author LanLinxiang
 * @version V1.0
 * @email linxianglan@aliyun.com
 * @date 2020-12-05
 */
@Service
public class DictionaryTypeServiseImpl implements DictionaryTypeServise {
    @Autowired
    private DictionaryTypeDao dictionaryTypeDao;

    @Override
    public List<DicType> findAll() {
        return dictionaryTypeDao.findAll();
    }

    @Override
    public boolean checkCode(String code) {

                int cont = dictionaryTypeDao.checkCode(code);
                if (0 <cont){
                    return false;
                }else {
                    return true;
                }
    }
/**
 * Description:字典类型表主键属性不同
 *              该字典类型主键有实际意义
 * @return
 * @date 2020/12/6 23:06
 */
    @Override
    public void saveDicType(DicType dicType) {
        dictionaryTypeDao.saveDicType(dicType);
    }

    @Override
    public DicType findByCode(String code) {
        return dictionaryTypeDao.findByCode(code);
    }

    @Override
    public int updateByID(DicType dicType) {
        return dictionaryTypeDao.updateByID(dicType);

    }

    @Override
    public int typeDelete(String[] codes) {
        int i = 0;
        for (String code:codes
             ) {
            dictionaryTypeDao.typeDelete(code);
            i++;
        }
        return i;
    }


}
