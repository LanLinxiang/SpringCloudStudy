package com.llx.crm.settings.web.controller;

import com.llx.crm.exception.TraditionRequestException;
import com.llx.crm.settings.domain.DicType;
import com.llx.crm.settings.service.DictionaryTypeServise;
import com.llx.crm.utils.HandleFlag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;

/**
 * Title: SettingsDictoyController
 * Description:
 *
 * @author LanLinxiang
 * @version V1.0
 * @email linxianglan@aliyun.com
 * @date 2020-12-03
 */
@Controller
@RequestMapping("/settings/dictionary")
public class SettingsDictoyController {
    @Autowired
    private DictionaryTypeServise dictionaryTypeServise;




    /**
     * Description:数据字典表设置页面
     * @return
     * @date 2020/12/3 22:31
     */
    @RequestMapping("/toIndex.do")
    public String toIndex(){
        return "/settings/dictionary/index";
    }



/**
 * Description:字典类型
 * @return
 * @date 2020/12/5 23:03
 */
    @RequestMapping("/type/toIndex.do")
    public String typetoIndex(Model model){
        //查询后台数据
        List<DicType> dicTypeList =  dictionaryTypeServise.findAll();
        //将表数据封装到Model中
       model.addAttribute("dicTypeList",dicTypeList);
        return "/settings/dictionary/type/index";
    }






    /**
     * Description:字典值新建页面
     * @return
     * @date 2020/12/6 0:07
     */
    @RequestMapping("/type/tosave.do")
    public ModelAndView typetoSave(){
        ModelAndView mv = new ModelAndView();
        mv.setViewName("/settings/dictionary/type/save");
        return mv;
    }
/**
 * Description:测试新增字段是否已重复
 * @return json
 * @date 2020/12/6 0:59
 */
    @RequestMapping("/type/checkCode.do")
    @ResponseBody
    public Map<String,Object> checkCode(String code){
        boolean flag = dictionaryTypeServise.checkCode(code);
        if(flag){
            return HandleFlag.successTrue();
        }else {
            return HandleFlag.erro("编码已重复");
        }

    }

    /**
     * Description:字典值新增
     * @return ResponseBody 响应回接收的数据
     * @date 2020/12/6 23:00
     */
    @RequestMapping("/type/save.do")
    @ResponseBody
    public  Map<String,Object> save(DicType dicType){
        //校验编码是否已重复
        boolean flag = dictionaryTypeServise.checkCode(dicType.getCode());
        if(flag){
           dictionaryTypeServise.saveDicType(dicType);
           return HandleFlag.successTrue();
        }else {
            return HandleFlag.erro("编码已重复");
        }




    }
/**
 * Description:根据选择信息调到对应修改页面
 * @return
 * @date 2020/12/7 0:55
 */
    @RequestMapping("/type/toEdit.do")
    public String toEdit(String code,Model model){
        //根据已知的Code 查出选中的数据
        DicType dicType = dictionaryTypeServise.findByCode(code);
        model.addAttribute("dicType",dicType);
        return "/settings/dictionary/type/edit";
    }

/**
 * Description:传参获取后台是否修改成功
 * @return
 * @date 2020/12/7 0:55
 */
    @RequestMapping("/type/update.do")
    @ResponseBody
    public  Map<String,Object> update(DicType dicType){
        int updateCount = dictionaryTypeServise.updateByID(dicType);
        if(0 < updateCount){
            return HandleFlag.successTrue();
        }else {
            return HandleFlag.erro("网络异常");
        }
    }


    @RequestMapping("/type/delete.do")
    public String typeDelete(String[] codes) throws TraditionRequestException {
        int count = dictionaryTypeServise.typeDelete(codes);
        if (count>0){
            return "redirect:/settings/dictionary/type/toIndex.do";
        }else {
            throw new TraditionRequestException("删除失败");
        }

    }

//==========================================type================================

//=========================================value===============================


    /**
     * Description:字典值
     * @return
     * @date 2020/12/5 23:03
     */
    @RequestMapping("/value/toIndex.do")
    public String valuetoIndex(){
        return "/settings/dictionary/value/index";
    }




}
